# Код поэтапной разработки сайта-портфолио для Proglib

[Flask за час. Часть 1: создаем адаптивный сайт для GitHub Pages](https://proglib.io/p/flask-za-chas-chast-1-sozdaem-adaptivnyy-sayt-dlya-github-pages-2022-06-20)

[Flask за час. Часть 2: завершаем разработку и размещаем сайт на GitHub Pages](https://proglib.io/p/flask-za-chas-chast-2-zavershaem-razrabotku-i-razmeshchaem-sayt-na-github-pages-2022-06-22)

[Готовый сайт](https://natkaida.github.io/flask_site/)

![site](https://user-images.githubusercontent.com/85797091/176396130-943941d7-a5de-4828-af88-c5ed2657032f.jpg)
